define( [
	"../../core",
	"../../selector"
], function( jQuery ) {
	"use strict";

	return jQuery.expr.match.needsContext;
} );
